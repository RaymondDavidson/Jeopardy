from distutils.core import setup
setup(name='Academic-Fair',
      version='1.0',
      py_modules=['jeopardy-tk'],
	  package_data={'academic-fair': ['data/*.dat']},
      )
